var dir_a05c63b09d645ddb1c0154724b085a55 =
[
    [ "socket.h", "socket_8h.html", null ]
];