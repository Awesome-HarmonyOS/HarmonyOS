var group__sys__misc =
[
    [ "sys_msleep", "group__sys__misc.html#ga6b8786f43e779953e8b74e983c88682e", null ],
    [ "sys_thread_new", "group__sys__misc.html#ga0d596afdd8dbcfad320172d39b0f607a", null ]
];